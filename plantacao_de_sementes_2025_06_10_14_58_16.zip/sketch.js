let seeds = [];
let plants = [];
function setup() {
  createCanvas(600, 400);
}
function draw() {
  background(200, 230, 180);
  // Sementes caindo ou germinando
  for (let i = seeds.length - 1; i >= 0; i--) {
    let seed = seeds[i];
    if (seed.falling) {
      seed.y += random(1, 3); // caindo lento
      fill(139, 69, 19);
      noStroke();
      ellipse(seed.x, seed.y, seed.size);

      if (seed.y > height - 50) {
        seeds.splice(i, 1);
        plants.push({
          x: seed.x,
          y: seed.y,
          height: 0,
          maxHeight: random(50, 100),
          stage: "germinating",
        });
      }
    }
  }
  // Crescimento das plantas
  for (let p of plants) {
    // Se passar o mouse por perto, cresce mais rápido
    if (dist(mouseX, mouseY, p.x, p.y) < 50) {
      p.height += 1; // crescimento mais rápido
    } else if (p.height < p.maxHeight) {
      p.height += 0.5;
    }
    if (p.stage === "germinating" && p.height >= p.maxHeight) {
      p.stage = "flower";
    }
    // desenhar planta
    push();
    translate(p.x, p.y);
    stroke(34, 139, 34);
    strokeWeight(4);
    line(0, 0, 0, -p.height);
    if (p.stage === "flower") {
      fill(255, 200, 0);
      noStroke();
      ellipse(0, -p.height - 5, 10, 10);
    }
    pop();
  }
}
function mousePressed() {
  // Ao clicar, uma semente cai na posição do mouse
  seeds.push({
    x: mouseX,
    y: 0,
    size: 4,
    falling: true,
  });
}
